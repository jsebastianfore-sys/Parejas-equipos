import { Component } from '@angular/core';


type Card = {
  id: number;
  key: string;
  emoji: string;
  revealed: boolean;
  matched: boolean;
}

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: false,
})
export class HomePage {

  pairs = 8;
  emojis = [
    '🍎', '🍊', '🍌', '🍉',
    '🍇', '🍓', '🍍', '🥭',
    '🥝', '🍒', '🍑', '🍋',
    '🥥', '🥑', '🍐', '🫐'
  ];

  cards: Card[] = [];
  firstClick: Card | null = null;
  secondClick: Card | null = null;
  attemps: number = 0;
  maches: number = 0;
  boardLocked = false; 

  constructor() { }

  ngOnInit() {
    this.newGame();
  }


  newGame() {
    this.attemps = 0;
    this.maches = 0;
    this.firstClick = null;
    this.secondClick = null;
    this.boardLocked = false;
    const selected: string[] = this.emojis.slice(0, this.pairs);

    const deck: Card[] = selected.flatMap<Card>((e: string, i: number) => ([
      { id: i * 2, key: 'k' + i, emoji: e, revealed: false, matched: false },
      { id: i * 2 + 1, key: 'k' + i, emoji: e, revealed: false, matched: false }
    ]));

    for (let i = deck.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [deck[i], deck[j]] = [deck[j], deck[i]]
    }

    this.cards = deck;
  }

  onCardClick(card: Card) {

    if (card.matched || card.revealed) {
      return;
    }

    card.revealed = true;

    if (!this.firstClick) {
      this.firstClick = card;
      return;
    }

    if (!this.secondClick) {
      this.secondClick = card;
      this.boardLocked = true;
      const match = this.firstClick.key === this.secondClick.key;

      if (match) {
        this.firstClick.matched = true;
        this.secondClick.matched = true;
        this.resetPick();
      } else {
        setTimeout(() => {
          if (this.firstClick) {
            this.firstClick.revealed = false;
          }
          if (this.secondClick) {
            this.secondClick.revealed = false;
          }
          this.resetPick();
        }, 900)
      }
    }
  }

  resetPick() {
    this.firstClick = null;
    this.secondClick = null;
    this.boardLocked = false;
  }

}
